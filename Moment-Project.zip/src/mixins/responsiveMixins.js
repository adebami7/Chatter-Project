export default {
    data() {
      return {
        isSmallScreen: window.innerWidth <= 768,
      };
    },
    methods: {
      // Add any common responsive methods or logic here
    },
    mounted() {
      window.addEventListener('resize', this.handleResize);
    },
    beforeDestroy() {
      window.removeEventListener('resize', this.handleResize);
    },
    methods: {
      handleResize() {
        this.isSmallScreen = window.innerWidth <= 768;
      },
    },
  };
  