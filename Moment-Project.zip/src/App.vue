<script setup lang="ts">
import { RouterView } from 'vue-router'
</script>

<template>
  <RouterView />
</template>

<style scoped>

/* Media query for small screens */
@media (max-width: 768px) {
  .my-component {
    padding: 10px;
  }
}
</style>