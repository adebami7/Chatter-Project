<script lang="ts" setup>
import Blog from "../components/Blog.vue"
</script>


<template>
    <Blog 
    />  
</template>
