<script lang="ts" setup>
import Feed from "../components/Feed.vue"
</script>


<template>
    <Feed 
    />  
</template>