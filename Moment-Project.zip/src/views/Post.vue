<script lang="ts" setup>
import Post from "../components/Post.vue"
</script>


<template>
    <Post 
    />  
</template>
