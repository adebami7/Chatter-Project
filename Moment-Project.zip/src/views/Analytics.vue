<script lang="ts" setup>
import Analytics from "../components/Analytics.vue"
</script>


<template>
    <Analytics
    />  
</template>
